"""Build portable v3 inputs without modifying v2.7 or document-owned attachments."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import ast
from preview30_ontology import generate, generate_relationships
from preview30_runtime import BASE, PREVIEW, WORKSHOP_VERSION, immutable_baseline, load, save


def write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists() or path.read_bytes() != data:
        path.write_bytes(data)


def build_relationships() -> dict:
    """Rebuild only the optional companion; no Agent, notebook or evidence writes."""
    parts, contract = generate_relationships(
        load(BASE / "ontology" / "ontology-full-definition-template.json"))
    root = PREVIEW / "ontology" / "relationships"
    for path, text in parts.items():
        write(root / "definition" / path, text.encode("utf-8"))
    save(root / "contract.json", contract)
    return {"tmdlParts": len(parts), "entityTypes": 10, "staticProperties": 72,
            "timeseriesProperties": 0, "relationshipTypes": 15, "deployed": False}


def build_agent_compatibility() -> dict:
    """Only portable legacy bridge inputs; never edit a candidate Agent profile."""
    from preview30_compatibility import build_template
    template, contract = build_template(load(BASE / "ontology/ontology-full-definition-template.json"))
    root = PREVIEW / "ontology/agent-compat"
    save(root / "definition-template.json", template)
    save(root / "contract.json", contract)
    return {"expectedGeneration": 1, **contract["counts"], "deployed": False,
            "implicitFallback": False, "agentConfigurationChanged": False}


def build_report_presentation() -> None:
    """Apply v3 display formatting after copying the immutable v2.7 report."""
    root = PREVIEW / "powerbi/Furusato_Analytics.Report/definition/pages/8c8fb549f9e148b18cb1/visuals"
    for visual_id in ("50713d2fda4c79f48be1", "6494ed6df2dc6827b12d", "8335b9428cb994ea095c"):
        path = root / visual_id / "visual.json"
        visual = load(path)
        properties = visual["visual"]["objects"]["labels"][0]["properties"]
        if properties["labelDisplayUnits"] != {"expr": {"Literal": {"Value": "'1000000'"}}}:
            raise ValueError("Unexpected inherited bar display units: " + visual_id)
        # Display units are numeric expressions; a string literal is ignored.
        properties["labelDisplayUnits"] = {"expr": {"Literal": {"Value": "1000000D"}}}
        save(path, visual)
    path = root / "4c3575e13ef9b6e97356" / "visual.json"
    visual = load(path)
    properties = visual["visual"]["objects"]["value"][0]["properties"]
    if "labelDisplayUnits" in properties or "labelPrecision" in properties:
        raise ValueError("Unexpected inherited card display overrides")
    # Show complete yen/count values instead of Auto's rounded K/bn labels.
    properties["labelDisplayUnits"] = {"expr": {"Literal": {"Value": "1D"}}}
    properties["labelPrecision"] = {"expr": {"Literal": {"Value": "0D"}}}
    save(path, visual)


V3_FACT_DESCRIPTIONS = (
    ("/// 静的seed寄附と重複排除済み増分イベントを統合した1寄附1行のファクト。金額・件数・時系列分析の基点です。",
     "/// 静的データ（配布した寄付データ全体）と、品質処理で重複を除いた受入済みの増分を合わせた、1寄付1行のファクトです。金額・件数・時系列分析の基点です。"),
    ("\t/// 現在のフィルター条件に含まれる寄附件数。静的seedと重複排除済み増分イベントを含みます。",
     "\t/// 現在のフィルター条件に含まれる寄附件数です。静的データと、重複を除いた受入済みの増分を含みます。"),
    ("\t/// StaticSeedまたはRealtimeIncrement。静的スナップショットと増分イベントを区別します。",
     "\t/// StaticSeed（静的データ）または RealtimeIncrement（受入済みの増分）。データの種類を区別します。"),
)


def _alignment_version(path: Path) -> str:
    text = path.read_text(encoding="utf-8").strip()
    if path.suffix.lower() == ".json":
        value = json.loads(text)
        if not isinstance(value, dict) or not isinstance(value.get("workshopVersion"), str):
            raise ValueError("Alignment source must contain a workshopVersion string.")
        return value["workshopVersion"]
    return text


def build_preview_contract(baseline: dict, *, contract_path: Path | None = None,
                           align_preview_contract_from: Path | None = None) -> dict:
    contract_path = contract_path or PREVIEW / "provisioning" / "preview-contract.json"
    if contract_path.is_file():
        existing = load(contract_path)
        if not isinstance(existing, dict) or existing.get("edition") != "v3.0.0-preview":
            raise ValueError("Existing preview contract has an unexpected runtime edition.")
        if existing.get("workshopVersion") != WORKSHOP_VERSION:
            if align_preview_contract_from is None:
                raise ValueError(
                    "Existing preview contract workshopVersion is stale; "
                    "supply --align-preview-contract-from with the canonical version source."
                )
            aligned_version = _alignment_version(align_preview_contract_from)
            if aligned_version != WORKSHOP_VERSION:
                raise ValueError(
                    "Preview contract alignment source does not match WORKSHOP_VERSION."
                )
    elif align_preview_contract_from is not None:
        aligned_version = _alignment_version(align_preview_contract_from)
        if aligned_version != WORKSHOP_VERSION:
            raise ValueError(
                "Preview contract alignment source does not match WORKSHOP_VERSION."
            )

    return {
        "edition": "v3.0.0-preview", "workshopVersion": WORKSHOP_VERSION, "baselineEdition": "2.7.0",
        "baselineTreeSha256": baseline["treeSha256"],
        "dataContract": {k: v for k, v in baseline.items() if k not in {"files", "treeSha256"}},
        "generation2": True, "legacyFallback": False,
        "ontologyContract": "../ontology/generation2-contract.json",
        "environmentParameterRequired": ["dev", "test", "prod"],
        "privateEvidenceRequired": True, "cloudStatus": "not-deployed-by-build",
        "productionPlacement": "specified-folder-direct", "createTempByDefault": False,
        "correctedAgentProfile": "data-agent/candidates/measured-contract-20261015",
        "attachmentsOwner": "documents-workstream",
    }


def build(*, align_preview_contract_from: Path | None = None) -> dict:
    baseline = immutable_baseline()
    # No recursive destination delete/copy: attachments is another workstream's.
    for folder in ("data", "kql", "powerbi"):
        for path in sorted((BASE / folder).rglob("*")):
            if path.is_file():
                write(PREVIEW / path.relative_to(BASE), path.read_bytes())
    build_report_presentation()
    fact_path = PREVIEW / "powerbi/Furusato_Analytics.SemanticModel/definition/tables/寄附.tmdl"
    fact = fact_path.read_text(encoding="utf-8")
    native_metrics = [
        ("静的寄附総額", 'CALCULATE([寄附総額], KEEPFILTERS(\'寄附\'[データソース] = "StaticSeed"))',
         "¥#,##0", "静的データ（StaticSeed）の寄附だけを集計します。Eventhouse の観測データや受入済みの増分は含めません。"),
        ("静的寄附件数", 'CALCULATE([寄附件数], KEEPFILTERS(\'寄附\'[データソース] = "StaticSeed"))',
         "#,##0", "静的データ（StaticSeed）の寄附件数です。現在のディメンションのフィルターを保ちます。"),
        ("受入増分寄附総額", 'CALCULATE([寄附総額], KEEPFILTERS(\'寄附\'[データソース] = "RealtimeIncrement"))',
         "¥#,##0", "Notebook05 で品質を確認し、重複を除いた受入済みの増分（RealtimeIncrement）だけを集計します。Eventhouse の観測データ（重複を含む）とは別です。"),
        ("受入増分寄附件数", 'CALCULATE([寄附件数], KEEPFILTERS(\'寄附\'[データソース] = "RealtimeIncrement"))',
         "#,##0", "Notebook05 で品質を確認し、重複を除いた受入済みの増分（RealtimeIncrement）の件数です。"),
    ]
    # Plain wording for descriptions inherited from the immutable 2.7.0 model (v3 copy only).
    for old, new in V3_FACT_DESCRIPTIONS:
        if fact.count(old) != 1:
            raise ValueError("Expected one inherited description to reword: " + old)
        fact = fact.replace(old, new)
    measure_text = ""
    for name, dax, fmt, text in native_metrics:
        text += " KEEPFILTERS は同じ列の既存条件との共通部分を取り、条件が矛盾する場合の BLANK を0に読み替えません。"
        measure_text += (f"\t/// {text}\n\tmeasure {name} = {dax}\n"
                         f"\t\tformatString: {fmt}\n\t\tdisplayFolder: Metrics検証\n\n")
    insertion = fact.index("\n\t///")
    fact = fact[:insertion] + "\n\n" + measure_text + fact[insertion:]
    # The amount is a participant-facing filter; expose only this column.
    # This does not certify the Data Agent's independently cached native schema.
    amount = "\tcolumn 寄附金額\n\t\tdataType: int64\n\t\tisHidden\n"
    if fact.count(amount) != 1:
        raise ValueError("Expected exactly one inherited amount visibility declaration")
    fact = fact.replace(amount, "\tcolumn 寄附金額\n\t\tdataType: int64\n")
    # Business totals use explicit measures; the visible amount remains a filter.
    amount_summary = "\t\tsummarizeBy: sum\n\t\tsourceColumn: DonationAmountYen"
    if fact.count(amount_summary) != 1:
        raise ValueError("Expected exactly one inherited amount summarization")
    fact = fact.replace(amount_summary,
                        "\t\tsummarizeBy: none\n\t\tsourceColumn: DonationAmountYen")
    write(fact_path, fact.encode("utf-8"))
    save(PREVIEW / "powerbi" / "native-metrics-contract.json", {
        "source": "Furusato_Analytics.SemanticModel",
        "storageMode": "DirectLake", "factSource": "gold.donations",
        "dimensionSources": ["gold.donor", "gold.municipality", "gold.gift", "gold.date"],
        "measures": [{"table": "寄附", "name": name, "dax": dax, "formatString": fmt}
                     for name, dax, fmt, _ in native_metrics],
        "sourceOwnsDax": True, "ontologyProjection": "native-ui-required",
        "dataAgentRequiresDirectSemanticModelSource": True,
        "validationState": "offline-only-not-executed",
    })
    for number in ("01", "05"):
        path = next((BASE / "notebooks").glob(f"Notebook_{number}_*.ipynb"))
        notebook = load(path)
        notebook["metadata"].setdefault("furusato", {}).update({
            "edition": "v" + WORKSHOP_VERSION, "version": WORKSHOP_VERSION,
            "runtimeProfile": "v3.0.0-preview", "sourceRuntimeEdition": "2.7.0",
            "dataContract": "2.7.0-realistic.1", "dataContractPreserved": True,
        })
        notebook["cells"][0]["source"] = [
            "# Furusato Workshop " + WORKSHOP_VERSION + " — " + path.stem + "\n", "\n",
            "**Workshop version / 教材版:** " + WORKSHOP_VERSION + "\n",
            "**Runtime profile / 技術的な配置識別子:** v3.0.0-preview\n",
            "**Compatible processing baseline / 処理基線:** 2.7.0. The data-processing algorithm is preserved.\n",
            "**Data contract / 不変のデータ仕様:** 2.7.0-realistic.1. CSV values and publication keys are unchanged.\n",
            "**Input boundary:** Lakehouse static/staging tables and released CSV files; never Eventhouse-to-Gold.\n",
            "**Deployment:** the specified folder directly; no Temp folder is required for production.\n",
        ]
        if number == "01":
            parameters = [cell for cell in notebook["cells"]
                          if "parameters" in cell.get("metadata", {}).get("tags", [])]
            if len(parameters) != 1 or parameters[0]["source"].count('NOTEBOOK_VERSION = "2.7.0"\n') != 1:
                raise ValueError("Expected one presentation/audit version assignment in Notebook01.")
            parameters[0]["source"] = [
                f'NOTEBOOK_VERSION = "{WORKSHOP_VERSION}"\n' if line == 'NOTEBOOK_VERSION = "2.7.0"\n' else line
                for line in parameters[0]["source"]
            ]
        if number == "05":
            final_cell = notebook["cells"][-1]
            source = final_cell["source"]
            if "IS_INTERACTIVE = bool(context.get(\"isForInteractive\", False))\n" not in source:
                marker = 'workspace_name = context["currentWorkspaceName"]\n'
                if source.count(marker) != 1:
                    raise ValueError("Notebook05 runtime context changed; cannot add the noninteractive result contract.")
                source.insert(source.index(marker) + 1,
                              'IS_INTERACTIVE = bool(context.get("isForInteractive", False))\n')
            old_gate = '    is_interactive=bool(context.get("isForInteractive", False)),\n'
            new_gate = "    is_interactive=IS_INTERACTIVE,\n"
            if old_gate in source:
                if source.count(old_gate) != 1:
                    raise ValueError("Notebook05 interactive gate is ambiguous.")
                source[source.index(old_gate)] = new_gate
            elif source.count(new_gate) != 1:
                raise ValueError("Notebook05 interactive gate changed unexpectedly.")
            if not any("notebookutils.notebook.exit" in line for line in source):
                if source and not source[-1].endswith("\n"):
                    source[-1] += "\n\n"
                source.extend([
                    "if not IS_INTERACTIVE:\n",
                    "    notebookutils.notebook.exit(json.dumps(\n",
                    "        ANALYTICS_RESULT, ensure_ascii=False, sort_keys=True, allow_nan=False,\n",
                    "    ))\n",
                ])
            if sum("notebookutils.notebook.exit" in line for line in source) != 1:
                raise ValueError("Notebook05 noninteractive exit-value emission is ambiguous.")
            preview = notebook["cells"][-2]
            note = (
                "A successful noninteractive run returns the unchanged `ANALYTICS_RESULT`\n"
                "JSON through the Notebook Public API job `exitValue`; interactive runs\n"
                "continue to show the printed summary below.\n"
            )
            if note not in "".join(preview["source"]):
                insertion = "the interactive default and all other apply gates remain unchanged.\n"
                text = "".join(preview["source"])
                if text.count(insertion) != 1:
                    raise ValueError("Notebook05 apply instructions changed; cannot document its result contract.")
                text = text.replace(insertion, insertion + note)
                preview["source"] = text.splitlines(keepends=True)
        write(PREVIEW / "notebooks" / path.name,
              (json.dumps(notebook, ensure_ascii=False, indent=1) + "\n").encode("utf-8"))
        if number == "05":
            runtime_tree = ast.parse("".join(notebook["cells"][3]["source"]))
            outputs = next(ast.literal_eval(n.value) for n in runtime_tree.body
                           if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "OUTPUT_TABLES" for t in n.targets))
            save(PREVIEW / "provisioning/gold-contract.json", {
                "outputTables": outputs, "generationColumn": "_AnalyticsGenerationId",
                "controlTable": "ops.analytics_publish_control", "readyState": "Ready",
                "inputs": ["Lakehouse static/staging tables", "Files/increment/*.csv"],
                "eventhouseToGold": False,
            })
    original = load(BASE / "ontology" / "ontology-full-definition-template.json")
    tmdl, contract = generate(original)
    for path, text in tmdl.items():
        write(PREVIEW / "ontology" / "definition" / path, text.encode("utf-8"))
    save(PREVIEW / "ontology" / "generation2-contract.json", contract)
    build_relationships()
    build_agent_compatibility()
    from preview30_agent import build_profile
    agent_files, agent_contract = build_profile()
    for path, content in agent_files.items():
        save(PREVIEW / "data-agent/definition" / path, content)
    save(PREVIEW / "data-agent/candidate-contract.json", agent_contract)
    save(PREVIEW / "provisioning" / "preview-contract.json",
         build_preview_contract(baseline, align_preview_contract_from=align_preview_contract_from))
    from preview30_notebooks import build_notebooks
    notebook_manifest = build_notebooks()
    save(PREVIEW / "provisioning/notebook-bundle-manifest.json", notebook_manifest)
    immutable_baseline()
    return {"edition": "v3.0.0-preview", "tmdlParts": len(tmdl),
            "dataPreserved": True, "attachmentsPreserved": True,
            "timeSeriesBinding": contract["timeSeriesBinding"]["status"],
            "nativeMetrics": contract["nativeMetrics"]["status"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--relationships-only", action="store_true",
                       help="Build only the opt-in static companion TMDL and contract.")
    group.add_argument("--agent-compat-only", action="store_true",
                       help="Build only the explicit generation1 consumer-bridge inputs.")
    parser.add_argument("--align-preview-contract-from", type=Path,
                        help="Explicitly align a stale preview contract using WORKSHOP_VERSION or a contract JSON.")
    args = parser.parse_args()
    if args.align_preview_contract_from and (args.relationships_only or args.agent_compat_only):
        parser.error("--align-preview-contract-from applies only to a full preview build.")
    action = build_relationships if args.relationships_only else build_agent_compatibility if args.agent_compat_only else build
    result = build(align_preview_contract_from=args.align_preview_contract_from) if action is build else action()
    print(json.dumps(result,
                     ensure_ascii=False, indent=2))
