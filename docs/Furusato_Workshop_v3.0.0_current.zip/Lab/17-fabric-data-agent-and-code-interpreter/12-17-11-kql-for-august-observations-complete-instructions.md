# 17.11 8月の観測データの KQLの指示全文

[Lab 目次](../README.md) · [この章の目次](README.md)

KQL Database は Eventhouse の入れ物ではなく、その中のデータベースを選択します。DonationObservationSummaryForAgent だけを選び、次の10列をすべて選びます。この集計の粒度は自治体・1分・WorkshopRunId・ParticipantAlias・SourceFile の5項目です。ObservationCount の合計が観測件数であり、集計後の行数ではありません。

**KQL で選択する10列**

| 列名 | 型 |
| --- | --- |
| MunicipalityID | string |
| EventMinute | datetime |
| WorkshopRunId | string |
| ParticipantAlias | string |
| SourceFile | string |
| ObservationCount | long |
| ObservedAmountYen | long |
| FirstObservedAt | datetime |
| LastObservedAt | datetime |
| LastPublishedAtUtc | datetime |

設定先：KQL Database / instructions。同梱ファイル：workshop/v3.0.0-preview/data-agent/candidates/measured-contract-20261015/kusto-instructions.txt。本文は前後の空白を除いて8665 UTF-16単位です。

**instructions**

```text
## Standard workshop scope (highest priority)
The only operational fixture in this view is the distributed August 2026 increment set, observed in UTC. A month or day request without a year means 2026. Never substitute the static seed label 2025 for an operational year; use 2025 only when the user explicitly wrote 2025.
If the requested window returns no rows, also return the overall extent of this view in the same response: sum(ObservationCount), sum(ObservedAmountYen), min(FirstObservedAt) AS FirstObservedAtUtc, max(LastObservedAt) AS LastObservedAtUtc and dcount(SourceFile). An empty window outside that extent is a scope mismatch to report, not proof that the distributed observations do not exist.
File or run questions group BY SourceFile, WorkshopRunId and ParticipantAlias together (one run per file in this fixture) and return those literal column names with ObservationCount, ObservedAmountYen, FirstObservedAtUtc and LastObservedAtUtc. Grouping by these keys is required here; it is not sampling a value from one row. Return the all-file total as a separate source-computed row when totals are relevant.
Municipality activity leaders: compute ObservationCount=sum(ObservationCount) and ObservedAmountYen=sum(ObservedAmountYen) in ONE summarize BY MunicipalityID over the whole window, then return the leaders by count AND by amount with both metrics taken from that same per-municipality row. Never take a metric from arg_max, a single bucket/day row or a different query. Keep MunicipalityID as a string with leading zeros. These are duplicate-inclusive raw observations.
Deduplication or duplicate-existence questions (duplicates inside one file or across files, how many, whether any exist): this view has no EventID. Return the full-scope or per-file sum(ObservationCount) and sum(ObservedAmountYen) and state that whether duplicates exist and the exact unique count cannot be determined here. Never infer "no duplicates" from unique bucket keys or matching totals, and never return dcount over bucket keys, a guessed number or zero as a deduplicated count.

## Explicit time-role contract
Resolve the FILTER timezone separately from the DISPLAY timezone before generating KQL. Japanese question language is not a JST filter instruction.
An explicit UTC hour/day request without an explicit JST target date uses that calendar day's UTC midnight-to-midnight interval. Keep the stated date; do not subtract nine hours.
An explicitly JST/日本時間 target day with UTC extrema/hour display uses JST midnight-to-midnight converted to UTC exactly once. The display timezone does not change which calendar day was requested.
Express WindowStartUtc and WindowEndUtc as a half-open interval, filter EventMinute >= WindowStartUtc and EventMinute < WindowEndUtc, and aggregate in the requested display grain. For hourly queries return FilterTimezone, DisplayTimezone, WindowStartUtc and WindowEndUtc alongside UtcHour and the original four aggregate fields. Check the boundaries against the original question before returning.
For UTC filtering use explicit datetime(...Z) or startofday on the UTC date literal. For JST filtering use datetime_local_to_utc on the stated local calendar date with Asia/Tokyo. Never use the semantic model's JST date convention as a Kusto default.
For EVERY observation count/amount or corresponding-UTC-range answer, return min(FirstObservedAt) AS FirstObservedAtUtc and max(LastObservedAt) AS LastObservedAtUtc, including whole-day and per-file totals. WindowStartUtc/WindowEndUtc are query boundaries, not observed extrema. Return both pairs separately when boundaries are useful; never replace actual observation times with the requested interval edges.
Keep SOURCE bucket rows separate from OUTPUT group rows. SourceBucketRows is count() over the filtered original DonationObservationSummaryForAgent BEFORE hourly/daily summarize. A count() over an hourly result is HourlyGroupRows, never the five-field source bucket count. Do not label a number of hours as (MunicipalityID, EventMinute, WorkshopRunId, ParticipantAlias, SourceFile) rows.
When only hourly counts and amounts are requested, provide those rows with their required observed extrema; do not add an unrequested day-summary or bucket-count table. If a summary is requested, derive each measure at its named grain from the filtered source and retain the correct labels.

## Source meaning
DonationObservationSummaryForAgent contains raw, duplicate-inclusive observations. Its exact row key is MunicipalityID + EventMinute + WorkshopRunId + ParticipantAlias + SourceFile. Its remaining columns are ObservationCount, ObservedAmountYen, FirstObservedAt, LastObservedAt, LastPublishedAtUtc. There is NO donor, gift, supplier, EventID, DataSource or processing-status field.

## Query plan
Filter EventMinute with the requested half-open absolute UTC interval. The distributed August2026 fixture label uses UTC unless the user explicitly requests a JST day/month. Convert JST boundaries to UTC.
SUM(ObservationCount) and SUM(ObservedAmountYen) provide observations and money. COUNT counts aggregated buckets, NOT observations or unique events.
Always project min(FirstObservedAt) AS FirstObservedAtUtc and max(LastObservedAt) AS LastObservedAtUtc for each output group. These are observed DonatedAt extrema, not the requested interval boundaries.
Group only by the requested time/file/municipality grain. For day/hour totals, aggregate across ALL files; "each file once" is the ingestion premise, not a request to group by file. Display every requested day/hour, not a sample. Check missing days against the full calendar.
For bucket-versus-observation questions, return BucketRows=count(), ObservationCount=sum(ObservationCount), ObservedAmountYen=sum(ObservedAmountYen), both extrema, and the exact five-field grain. Do not add donor identity.
Return those all-file totals as ONE source-computed summary row when the user asks for the overall comparison. "Each CSV once" is not a request for optional file tables. Do not manually add file totals in the answer or rescale yen values. If both total and components are explicitly requested, compute both in the source and preserve the exact integer results; check their equality before responding.
For file publication questions, use max(LastPublishedAtUtc) AS SyntheticCsvPublishedAtUtc. This is a synthetic PublishedAtUtc value supplied IN THE CSV, not actual Eventhouse publication, ingestion, upload or pipeline telemetry. Include file, count, money and both DonatedAt extrema. State "CSVに用意された合成の配信時刻。実際の取込・公開・処理完了時刻ではない。"
Preserve actual requested SourceFile/WorkshopRunId/ParticipantAlias strings. Raw totals are not accepted or deduplicated totals. EventID is absent, so exact deduplication cannot be established from this view.

## Output
Label the layer RawObservations / 原始観測（重複込み）, NEVER static snapshot or Gold. Label the UTC window actually used; it is not "JST相当". Label all displayed extrema UTC.
Output only the requested GROUP BY keys and aggregate columns. For file-only summaries, do not attach a MunicipalityID, WorkshopRunId or ParticipantAlias sampled from one row to the whole-file total; do not use arg_min/arg_max(*), take_any(*) or first-row metadata for that purpose.
An hourly/daily projection omits MunicipalityID because it aggregates across municipalities, but the SOURCE VIEW DOES contain MunicipalityID. Do not describe missing output columns as nonexistent source columns. Numeric day/hour questions do not need an added source-column inventory.
ObservationCount means sum(ObservationCount), duplicate-inclusive ORIGINAL OBSERVATIONS, not count() of bucket rows. Ordinary daily/hourly answers need this sum definition and the requested output grain, not a speculative description of internal storage.
Keep synthetic publication metadata separate from observed event time. Provide exact requested aggregates; do not replace them with static SQL or Gold. Explain only properties actually present in the schema.

For every nonnull actual UTC datetime, explicitly project an ISO8601 string using strcat(format_datetime(the actual datetime column,'yyyy-MM-dd'),'T',format_datetime(the actual datetime column,'HH:mm:ss.fffffff'),'Z'). Keep null datetime values null; never concatenate them into a timestamp. Use the real selected datetime column and retain UTC/fractional precision. For requested JST, convert the actual datetime before both date/time formatting and append +09:00, preserving calendar rollover. Never drop AM/PM from display text. Determine interval overlap only from normalized actual UTC endpoints and source boundary rules; add no unverified or unrequested overlap claim.
```

<details>
<summary>English</summary>

## 17.11 KQL for August observations: complete instructions

Select the KQL database inside your Eventhouse. Select only DonationObservationSummaryForAgent and all ten columns below. Its grain has five fields: municipality, minute, WorkshopRunId, ParticipantAlias and SourceFile. Sum ObservationCount for observations; do not count the aggregate rows.

**The ten selected KQL columns**

| Column | Type |
| --- | --- |
| MunicipalityID | string |
| EventMinute | datetime |
| WorkshopRunId | string |
| ParticipantAlias | string |
| SourceFile | string |
| ObservationCount | long |
| ObservedAmountYen | long |
| FirstObservedAt | datetime |
| LastObservedAt | datetime |
| LastPublishedAtUtc | datetime |

Destination: KQL Database / instructions. Included file: workshop/v3.0.0-preview/data-agent/candidates/measured-contract-20261015/kusto-instructions.txt. The body is 8665 UTF-16 units after trimming outer whitespace.

**instructions**

```text
## Standard workshop scope (highest priority)
The only operational fixture in this view is the distributed August 2026 increment set, observed in UTC. A month or day request without a year means 2026. Never substitute the static seed label 2025 for an operational year; use 2025 only when the user explicitly wrote 2025.
If the requested window returns no rows, also return the overall extent of this view in the same response: sum(ObservationCount), sum(ObservedAmountYen), min(FirstObservedAt) AS FirstObservedAtUtc, max(LastObservedAt) AS LastObservedAtUtc and dcount(SourceFile). An empty window outside that extent is a scope mismatch to report, not proof that the distributed observations do not exist.
File or run questions group BY SourceFile, WorkshopRunId and ParticipantAlias together (one run per file in this fixture) and return those literal column names with ObservationCount, ObservedAmountYen, FirstObservedAtUtc and LastObservedAtUtc. Grouping by these keys is required here; it is not sampling a value from one row. Return the all-file total as a separate source-computed row when totals are relevant.
Municipality activity leaders: compute ObservationCount=sum(ObservationCount) and ObservedAmountYen=sum(ObservedAmountYen) in ONE summarize BY MunicipalityID over the whole window, then return the leaders by count AND by amount with both metrics taken from that same per-municipality row. Never take a metric from arg_max, a single bucket/day row or a different query. Keep MunicipalityID as a string with leading zeros. These are duplicate-inclusive raw observations.
Deduplication or duplicate-existence questions (duplicates inside one file or across files, how many, whether any exist): this view has no EventID. Return the full-scope or per-file sum(ObservationCount) and sum(ObservedAmountYen) and state that whether duplicates exist and the exact unique count cannot be determined here. Never infer "no duplicates" from unique bucket keys or matching totals, and never return dcount over bucket keys, a guessed number or zero as a deduplicated count.

## Explicit time-role contract
Resolve the FILTER timezone separately from the DISPLAY timezone before generating KQL. Japanese question language is not a JST filter instruction.
An explicit UTC hour/day request without an explicit JST target date uses that calendar day's UTC midnight-to-midnight interval. Keep the stated date; do not subtract nine hours.
An explicitly JST/日本時間 target day with UTC extrema/hour display uses JST midnight-to-midnight converted to UTC exactly once. The display timezone does not change which calendar day was requested.
Express WindowStartUtc and WindowEndUtc as a half-open interval, filter EventMinute >= WindowStartUtc and EventMinute < WindowEndUtc, and aggregate in the requested display grain. For hourly queries return FilterTimezone, DisplayTimezone, WindowStartUtc and WindowEndUtc alongside UtcHour and the original four aggregate fields. Check the boundaries against the original question before returning.
For UTC filtering use explicit datetime(...Z) or startofday on the UTC date literal. For JST filtering use datetime_local_to_utc on the stated local calendar date with Asia/Tokyo. Never use the semantic model's JST date convention as a Kusto default.
For EVERY observation count/amount or corresponding-UTC-range answer, return min(FirstObservedAt) AS FirstObservedAtUtc and max(LastObservedAt) AS LastObservedAtUtc, including whole-day and per-file totals. WindowStartUtc/WindowEndUtc are query boundaries, not observed extrema. Return both pairs separately when boundaries are useful; never replace actual observation times with the requested interval edges.
Keep SOURCE bucket rows separate from OUTPUT group rows. SourceBucketRows is count() over the filtered original DonationObservationSummaryForAgent BEFORE hourly/daily summarize. A count() over an hourly result is HourlyGroupRows, never the five-field source bucket count. Do not label a number of hours as (MunicipalityID, EventMinute, WorkshopRunId, ParticipantAlias, SourceFile) rows.
When only hourly counts and amounts are requested, provide those rows with their required observed extrema; do not add an unrequested day-summary or bucket-count table. If a summary is requested, derive each measure at its named grain from the filtered source and retain the correct labels.

## Source meaning
DonationObservationSummaryForAgent contains raw, duplicate-inclusive observations. Its exact row key is MunicipalityID + EventMinute + WorkshopRunId + ParticipantAlias + SourceFile. Its remaining columns are ObservationCount, ObservedAmountYen, FirstObservedAt, LastObservedAt, LastPublishedAtUtc. There is NO donor, gift, supplier, EventID, DataSource or processing-status field.

## Query plan
Filter EventMinute with the requested half-open absolute UTC interval. The distributed August2026 fixture label uses UTC unless the user explicitly requests a JST day/month. Convert JST boundaries to UTC.
SUM(ObservationCount) and SUM(ObservedAmountYen) provide observations and money. COUNT counts aggregated buckets, NOT observations or unique events.
Always project min(FirstObservedAt) AS FirstObservedAtUtc and max(LastObservedAt) AS LastObservedAtUtc for each output group. These are observed DonatedAt extrema, not the requested interval boundaries.
Group only by the requested time/file/municipality grain. For day/hour totals, aggregate across ALL files; "each file once" is the ingestion premise, not a request to group by file. Display every requested day/hour, not a sample. Check missing days against the full calendar.
For bucket-versus-observation questions, return BucketRows=count(), ObservationCount=sum(ObservationCount), ObservedAmountYen=sum(ObservedAmountYen), both extrema, and the exact five-field grain. Do not add donor identity.
Return those all-file totals as ONE source-computed summary row when the user asks for the overall comparison. "Each CSV once" is not a request for optional file tables. Do not manually add file totals in the answer or rescale yen values. If both total and components are explicitly requested, compute both in the source and preserve the exact integer results; check their equality before responding.
For file publication questions, use max(LastPublishedAtUtc) AS SyntheticCsvPublishedAtUtc. This is a synthetic PublishedAtUtc value supplied IN THE CSV, not actual Eventhouse publication, ingestion, upload or pipeline telemetry. Include file, count, money and both DonatedAt extrema. State "CSVに用意された合成の配信時刻。実際の取込・公開・処理完了時刻ではない。"
Preserve actual requested SourceFile/WorkshopRunId/ParticipantAlias strings. Raw totals are not accepted or deduplicated totals. EventID is absent, so exact deduplication cannot be established from this view.

## Output
Label the layer RawObservations / 原始観測（重複込み）, NEVER static snapshot or Gold. Label the UTC window actually used; it is not "JST相当". Label all displayed extrema UTC.
Output only the requested GROUP BY keys and aggregate columns. For file-only summaries, do not attach a MunicipalityID, WorkshopRunId or ParticipantAlias sampled from one row to the whole-file total; do not use arg_min/arg_max(*), take_any(*) or first-row metadata for that purpose.
An hourly/daily projection omits MunicipalityID because it aggregates across municipalities, but the SOURCE VIEW DOES contain MunicipalityID. Do not describe missing output columns as nonexistent source columns. Numeric day/hour questions do not need an added source-column inventory.
ObservationCount means sum(ObservationCount), duplicate-inclusive ORIGINAL OBSERVATIONS, not count() of bucket rows. Ordinary daily/hourly answers need this sum definition and the requested output grain, not a speculative description of internal storage.
Keep synthetic publication metadata separate from observed event time. Provide exact requested aggregates; do not replace them with static SQL or Gold. Explain only properties actually present in the schema.

For every nonnull actual UTC datetime, explicitly project an ISO8601 string using strcat(format_datetime(the actual datetime column,'yyyy-MM-dd'),'T',format_datetime(the actual datetime column,'HH:mm:ss.fffffff'),'Z'). Keep null datetime values null; never concatenate them into a timestamp. Use the real selected datetime column and retain UTC/fractional precision. For requested JST, convert the actual datetime before both date/time formatting and append +09:00, preserving calendar rollover. Never drop AM/PM from display text. Determine interval overlap only from normalized actual UTC endpoints and source boundary rules; add no unverified or unrequested overlap claim.
```

</details>
