"""Source fidelity and usable copy blocks for the participant tuning procedure.

These checks render real OOXML/HTML locally. They neither contact Fabric nor
claim that a matching configuration guarantees the historical answer score.
"""

import ast
import copy
import csv
import io
import json
import re
import shutil
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from types import SimpleNamespace

from lxml import etree, html

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / "tools/docs"), str(ROOT / "tools/html"),
               str(ROOT / "tools/data-agent")]

import build_preview30 as builder
import validate_preview30 as validator
from furusato_docs import participant30_tuning as tuning
from furusato_docs import participant30_evaluation as evaluation
from furusato_docs import participant30_text as participant_text
from furusato_docs.participant30 import FigureFactory
from furusato_docs import preview30_release as release
from furusato_docs.oox import StyleCarrier
from furusato_docs.docx_kit import DocumentBuilder, CODE_BLOCK_CHUNK_LINES
from furusato_html.model import Block, Document, Section, Text
from furusato_html.render import RenderContext, render_block
from standard_contract_restoration import _answer_values_in
import native_evaluation


def chapter(number):
    return Section(ident=f"ch-{number}", level=1, number=str(number),
                   title=Text("参加者手順", "Participant procedure"), chapter=number)


def code_blocks(section):
    return [block for block in section.iter_blocks() if block.kind == "code"]


class ParticipantSelfServiceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tuning = chapter(17)
        cls.figures = FigureFactory(None, {})
        cls.counts = tuning.append_tuning_sections(cls.tuning, ROOT, figures=cls.figures)
        cls.document = Document([cls.tuning], [], [], [])
        cls.profile = ROOT / tuning.PROFILE_REL
        cls.instructions = {
            filename: (cls.profile / filename).read_text(encoding="utf-8").strip()
            for filename in ("global-instructions.txt", "lakehouse-instructions.txt",
                             "kusto-instructions.txt", "semantic-model-instructions.txt")
        }
        cls.examples = json.loads((cls.profile / "kusto-examples.json").read_text(encoding="utf-8"))["examples"]
        cls.selections = json.loads((cls.profile / "selection-contract.json").read_text(encoding="utf-8"))["sources"]
        cls.codes = code_blocks(cls.tuning)
        cls.code_texts = [block["text"] for block in cls.codes]

    def test_all_four_instruction_fields_are_complete_unmodified_and_fit_service_limit(self):
        instruction_blocks = [b for b in self.codes if b["language"].en == "instructions"]
        self.assertEqual(4, len(instruction_blocks))
        self.assertCountEqual(self.instructions.values(), [b["text"] for b in instruction_blocks])
        for filename, body in self.instructions.items():
            with self.subTest(filename=filename):
                self.assertEqual(1, self.code_texts.count(body))
                self.assertLessEqual(len(body.encode("utf-16-le")) // 2, 10000)
                self.assertEqual([], _answer_values_in(body))
        legacy = (self.profile / "ontology-instructions.txt").read_text(encoding="utf-8").strip()
        self.assertNotIn(legacy, self.code_texts)

    def test_kql_questions_and_queries_keep_every_original_pair_and_order(self):
        section = next(s for s in self.tuning.walk() if s.number == "17.12")
        actual = [(b["language"].en, b["text"]) for b in code_blocks(section)]
        expected = []
        for example in self.examples:
            expected.extend((("question", example["question"]), ("KQL", example["query"])))
        self.assertEqual(9, len(self.examples))
        self.assertEqual(expected, actual)

    def test_sql_selection_tables_cover_exactly_the_seventeen_objects_and_143_columns(self):
        section = next(s for s in self.tuning.walk() if s.number == "17.7")
        tables = [b for b in section.blocks if b.kind == "table"]
        objects = [n for n in self.selections["lakehouse_tables"]
                   if n["type"] in {"lakehouse_tables.table", "lakehouse_tables.view"}]
        object_names = {node["path"][1] + "." + node["path"][-1] for node in objects}
        selection_tables = [table for table in tables
                            if any(table["caption"].en.startswith(name + ":")
                                   for name in object_names)]
        self.assertEqual(17, len(objects))
        self.assertEqual(17, len(selection_tables))
        exclusions = [table for table in tables if table not in selection_tables]
        self.assertEqual(1, len(exclusions))
        self.assertEqual(
            "Six generation-metadata leaves outside the 143 business columns",
            exclusions[0]["caption"].en,
        )
        self.assertEqual(6, len(exclusions[0]["rows"]))
        self.assertEqual(143, sum(len(table["rows"]) for table in selection_tables))
        for node, table in zip(objects, selection_tables):
            path = node["path"]
            with self.subTest(object=path):
                self.assertTrue(table["caption"].en.startswith(path[1] + "." + path[-1] + ":"))
                expected = [(c["path"][-1], c["dataType"]) for c in self.selections["lakehouse_tables"]
                            if c["type"] == "lakehouse_tables.column" and c["path"][:-1] == path]
                for language in ("ja", "en"):
                    self.assertEqual(expected, [tuple(cell.get(language) for cell in row) for row in table["rows"]])

    def test_all_view_creation_and_schema_inventory_queries_are_included_verbatim(self):
        section = next(s for s in self.tuning.walk() if s.number == "17.6")
        expected = [(ROOT / relative).read_text(encoding="utf-8").strip() for relative in tuning.VIEW_RELS]
        expected.append((self.profile / "sql-schema-inventory.sql").read_text(encoding="utf-8").strip())
        self.assertEqual(6, len(tuning.VIEW_RELS))
        self.assertEqual(expected, [b["text"] for b in code_blocks(section)])

    def test_view_creation_order_satisfies_actual_sql_dependencies_and_notebook_base_tables(self):
        # Read the rendered order and the real SQL references, rather than
        # asserting a fixed pair of filenames. Fresh endpoints cannot create
        # a view before another view used by its SELECT already exists.
        section = next(s for s in self.tuning.walk() if s.number == "17.6")
        statements = [b["text"] for b in code_blocks(section)
                      if re.match(r"\s*CREATE\s+VIEW\b", b["text"], re.IGNORECASE)]
        identifier = r"(?:\[[^\]]+\]|[A-Za-z_][A-Za-z_0-9]*)"
        qualified = rf"{identifier}\s*\.\s*{identifier}"

        def normalize(name):
            return re.sub(r"[\[\]\s]", "", name).lower()

        names = [normalize(re.match(rf"\s*CREATE\s+VIEW\s+({qualified})\b", sql,
                                    re.IGNORECASE).group(1)) for sql in statements]
        self.assertEqual(6, len(names))
        self.assertEqual(6, len(set(names)))
        created = set()
        external = set()
        inter_view_dependencies = set()
        for name, sql in zip(names, statements):
            references = {normalize(value) for value in re.findall(
                rf"\b(?:FROM|JOIN)\s+({qualified})", sql, re.IGNORECASE)}
            internal = references.intersection(names)
            with self.subTest(view=name):
                self.assertFalse(internal - created,
                                 f"{name} is printed before its dependencies: {sorted(internal - created)}")
            inter_view_dependencies.update((name, dependency) for dependency in internal)
            external.update(references - set(names))
            created.add(name)
        self.assertTrue(inter_view_dependencies, "The real SQL dependency edge must be exercised")

        notebook = json.loads((ROOT / "workshop/v3.0.0-preview/notebooks/"
                               "Notebook_01_Furusato_Prepare_Ontology_Data.ipynb").read_text(encoding="utf-8"))
        contract_cell = next("".join(cell["source"]) for cell in notebook["cells"]
                             if "OUTPUT_ROW_COUNTS =" in "".join(cell.get("source", [])))
        counts = next(ast.literal_eval(node.value) for node in ast.parse(contract_cell).body
                      if isinstance(node, ast.Assign) and any(
                          isinstance(target, ast.Name) and target.id == "OUTPUT_ROW_COUNTS"
                          for target in node.targets))
        ready_base_tables = {"dbo." + name for name, count in counts.items() if count > 0}
        self.assertTrue(external)
        self.assertFalse(external - ready_base_tables,
                         f"View prerequisites are absent from Notebook 01 output: {sorted(external - ready_base_tables)}")

    def test_kql_columns_and_source_descriptions_match_canonical_sources(self):
        kql_section = next(s for s in self.tuning.walk() if s.number == "17.11")
        columns = [n for n in self.selections["kusto"] if n["type"] == "kusto.column"]
        self.assertEqual(10, len(columns))
        table = next(b for b in kql_section.blocks if b.kind == "table")
        self.assertEqual([(n["path"][-1], n["dataType"]) for n in columns],
                         [tuple(c.en for c in row) for row in table["rows"]])
        descriptions = json.loads((self.profile / "source-descriptions.json").read_text(encoding="utf-8"))
        section = next(s for s in self.tuning.walk() if s.number == "17.14")
        self.assertEqual([descriptions[k] for k in ("lakehouse_tables", "kusto", "semantic_model")],
                         [b["text"] for b in code_blocks(section)])

    def test_all_ten_dax_definitions_match_the_shipped_model_without_new_measures(self):
        compiler = ast.parse((ROOT / "tools/data-agent/measured_contract_profile.py").read_text(encoding="utf-8"))
        definitions = next(ast.literal_eval(n.value) for n in compiler.body
                           if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "MEASURES" for t in n.targets))
        model = (ROOT / "workshop/v3.0.0-preview/powerbi/Furusato_Analytics.SemanticModel/definition/tables/寄附.tmdl").read_text(encoding="utf-8")
        actual_model = {name.strip().strip("'"): value.strip() for name, value in
                        re.findall(r"^\s*measure (.+?)\s*=\s*(.+)$", model, re.MULTILINE)}
        self.assertEqual(10, len(definitions))
        self.assertEqual(definitions, actual_model)
        shown = [b["text"] for b in self.codes if b["language"].en == "DAX"]
        self.assertEqual([name + " = " + expression for name, expression in definitions.items()], shown)

    def test_modified_source_profile_is_rejected_before_documenting_it(self):
        with tempfile.TemporaryDirectory(prefix="participant-profile-tamper-") as directory:
            root = Path(directory)
            profile = root / tuning.PROFILE_REL
            shutil.copytree(self.profile, profile)
            with (profile / "global-instructions.txt").open("a", encoding="utf-8") as output:
                output.write("\nUnreviewed change\n")
            with self.assertRaisesRegex(ValueError, "source hash mismatch"):
                tuning.append_tuning_sections(chapter(17), root, figures=self.figures)

    def test_only_exact_attributed_literals_are_exempt_from_work_log_guard(self):
        canonical = list(validator.canonical_literals(self.document, "en"))
        self.assertTrue(canonical)
        for body in self.instructions.values():
            with self.subTest(instruction=body[:45]):
                self.assertIn(body, canonical)
                self.assertEqual([], validator.participant_working_content("\n".join(body.split()), self.document, "en"))
        quoted = next(value for value in canonical if validator.working_content(value))
        altered = "ALTERED_LITERAL " + quoted[1:]
        self.assertTrue(validator.participant_working_content(altered, self.document, "en"))
        self.assertIn("source commit", validator.participant_working_content(
            quoted + "\nUnrelated source commit: 1234567890", self.document, "en"))
        self.assertIn("76 PASS / 8 FAIL", validator.participant_working_content(
            quoted + "\n76 PASS / 8 FAIL", self.document, "ja"))
        unmarked = copy.deepcopy(self.document)
        for section in unmarked.walk():
            for block in section.blocks:
                block.payload.pop("canonicalLiteral", None)
        self.assertTrue(validator.participant_working_content(quoted, unmarked, "en"))

    def test_source_code_survives_actual_word_xml_and_html_copy_targets(self):
        # Use the release renderer with real source-bound code blocks. This is a
        # local structural fixture, not a release approval or page-layout claim.
        appendix = Section("appendix-c", 1, "C", Text("評価", "Evaluation"), appendix="C")
        evaluation.append_rubric_sections(appendix, ROOT)
        rendered_codes = self.codes + code_blocks(appendix)
        model = Document([Section("code-check", 1, "17", Text("コピー確認", "Copy check"),
                                  blocks=copy.deepcopy(rendered_codes), chapter=17)], [], [], [])
        with tempfile.TemporaryDirectory(prefix="participant-code-preservation-") as directory:
            work = Path(directory)
            target = work / "guide.docx"
            builder.write_word(model, None, StyleCarrier.resolve(ROOT), {"captures": {}},
                               {"version": release.PREVIEW.version, "contentSha256": "0" * 64,
                                "participantEdition": True}, target, work,
                               release_profile=release.PREVIEW, word_navigation="headings")
            with zipfile.ZipFile(target) as archive:
                doc = etree.fromstring(archive.read("word/document.xml"))
            ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
            paragraphs = ["".join(p.xpath(".//w:t/text()", namespaces=ns))
                          for p in doc.xpath("//w:p", namespaces=ns)]
            word_text = "\n".join(paragraphs)
            for block in rendered_codes:
                with self.subTest(word=block["text"][:50]):
                    self.assertIn(block["text"], word_text)
            self.assertIn("質問(日本語)", paragraphs)
            self.assertNotIn("質問（日本語）", paragraphs)

        context = RenderContext(ui={"copy.aria": {"ja": "コピー", "en": "Copy"},
                                    "copy.label": {"ja": "コピー", "en": "Copy"}},
                                assets=None, version="test", fingerprint="test", runtime_fingerprint="",
                                facts=None, context=SimpleNamespace(), stats={})
        counter = {"code": 0}
        markup = "<main>" + "".join(render_block(b, context, counter) for b in rendered_codes) + "</main>"
        page = html.fromstring(markup)
        nodes = page.xpath("//pre/code")
        self.assertEqual([b["text"] for b in rendered_codes], [node.text_content() for node in nodes])
        self.assertEqual([node.get("id") for node in nodes],
                         page.xpath("//button/@data-copy-target"))

    def test_code_label_stays_with_body_without_binding_later_chunks(self):
        # The actual release PDF dropped a short question when its separate
        # label row fit at the page foot. Row cantSplit alone did not prevent it.
        # A full-document LibreOffice before/after reproduction accompanies the
        # release review; this check guards its narrow pagination contract.
        from docx import Document as WordDocument
        from docx.oxml.ns import qn
        document = DocumentBuilder.__new__(DocumentBuilder)
        document.document = WordDocument()
        document._literal_text = []
        for keep_together, lines in ((True, ["A complete question"]),
                                     (False, [f"line {i}" for i in range(CODE_BLOCK_CHUNK_LINES + 1)])):
            with self.subTest(keep_together=keep_together):
                table = document.code_block("\n".join(lines), language="Question",
                                            keep_together=keep_together, verbatim=True)
                self.assertTrue(table.cell(0, 0).paragraphs[0].paragraph_format.keep_with_next)
                self.assertIsNotNone(table.rows[0]._tr.get_or_add_trPr().find(qn("w:tblHeader")))
                self.assertEqual(2 if keep_together else 3, len(table.rows))
                for row in table.rows[1:]:
                    self.assertIsNotNone(row._tr.get_or_add_trPr().find(qn("w:cantSplit")))
                    for paragraph in row.cells[0].paragraphs:
                        self.assertIsNot(paragraph.paragraph_format.keep_with_next, True)

    def test_canonical_table_punctuation_is_preserved_without_relaxing_ordinary_typography(self):
        blocks = [Block("table", {"number": 1, "caption": Text("比較", "Comparison"),
                  "headers": [Text("項目", "Field"), Text("値", "Value")],
                  "rows": [[Text("原文（固定）", "原文（固定）"), Text("条件（全文）", "条件（全文）")]],
                  "canonicalLiteral": True}),
                  Block("paragraph", {"text": Text("通常（説明）", "Ordinary（prose）")})]
        model = Document([Section("literal-check", 1, "17", Text("比較", "Comparison"), blocks=blocks)], [], [], [])
        with tempfile.TemporaryDirectory(prefix="participant-table-literals-") as directory:
            work = Path(directory)
            target = work / "guide.docx"
            builder.write_word(model, None, StyleCarrier.resolve(ROOT), {"captures": {}},
                               {"version": release.PREVIEW.version, "contentSha256": "0" * 64,
                                "participantEdition": True}, target, work,
                               release_profile=release.PREVIEW, word_navigation="headings")
            with zipfile.ZipFile(target) as archive:
                tree = etree.fromstring(archive.read("word/document.xml"))
            values = tree.xpath("//w:t/text()", namespaces={"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"})
            self.assertIn("原文（固定）", values)
            self.assertIn("条件（全文）", values)
            self.assertIn("通常(説明)", values)
            self.assertNotIn("通常（説明）", values)
        context = RenderContext(ui={"table.label": {"ja": "表", "en": "Table"},
                                    "table.scroll": {"ja": "スクロール", "en": "Scroll"}},
                                assets=None, version="test", fingerprint="test", runtime_fingerprint="",
                                facts=None, context=SimpleNamespace(), stats={})
        text = html.fromstring("<main>" + "".join(render_block(b, context, {"code": 0}) for b in blocks) + "</main>").text_content()
        self.assertIn("原文（固定）", text)
        self.assertIn("条件（全文）", text)
        self.assertIn("通常(説明)", text)
        self.assertNotIn("通常（説明）", text)

    def test_parentheses_validation_exempts_only_canonical_body_text(self):
        quoted = "原文（固定された指示）"
        block = Block("code", {"text": quoted, "language": Text("text", "text"), "canonicalLiteral": True})
        model = Document([Section("literal", 1, "17", Text("手順", "Steps"), blocks=[block])], [], [], [])
        namespace = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

        def parts(*values):
            tree = etree.Element("{" + namespace + "}document", nsmap={"w": namespace})
            for value in values:
                etree.SubElement(tree, "{" + namespace + "}t").text = value
            return {"word/document.xml": etree.tostring(tree)}

        good = validator.old.Report(target="canonical punctuation test")
        validator.check_participant_parentheses(parts(quoted, "通常(説明)"), model, good)
        self.assertTrue(good.passed)
        for value in ("通常（説明）", quoted.replace("固定された", "変更された")):
            # A changed literal must not acquire an exception merely because it
            # includes the same technical term or shares its trailing words.
            bad = validator.old.Report(target="unquoted punctuation test")
            validator.check_participant_parentheses(parts(quoted, value), model, bad)
            self.assertFalse(bad.passed)
        header = parts(quoted)
        header["word/header1.xml"] = parts("別の（ヘッダー）")["word/document.xml"]
        report = validator.old.Report(target="other story punctuation test")
        validator.check_participant_parentheses(header, model, report)
        self.assertFalse(report.passed)

    def test_canonical_punctuation_check_does_not_insert_spaces_between_formatting_runs(self):
        quoted = "increment-run-003（donation_events_003.csv）"
        model = Document([Section("literal", 1, "C", Text("原典", "Source"), blocks=[
            Block("paragraph", {"text": Text(quoted, quoted), "canonicalLiteral": True})])], [], [], [])
        namespace = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
        tree = etree.Element("{" + namespace + "}document", nsmap={"w": namespace})
        paragraph = etree.SubElement(tree, "{" + namespace + "}p")
        for value in ("increment-run-", "003", "（", "donation_events_003", ".csv", "）"):
            run = etree.SubElement(paragraph, "{" + namespace + "}r")
            etree.SubElement(run, "{" + namespace + "}t").text = value
        parts = {"word/document.xml": etree.tostring(tree)}
        report = validator.old.Report(target="split formatting runs")
        validator.check_participant_parentheses(parts, model, report)
        self.assertTrue(report.passed, report.failures)
        etree.SubElement(tree, "{" + namespace + "}t").text = "未引用（別の説明）"
        report = validator.old.Report(target="unquoted text outside paragraph")
        validator.check_participant_parentheses({"word/document.xml": etree.tostring(tree)}, model, report)
        self.assertFalse(report.passed)


class ParticipantEvaluationMaterialsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = ROOT / evaluation.ASSET_RELATIVE
        cls.suite = evaluation.load_suite(ROOT)
        cls.cases = cls.suite["original"]["cases"] + cls.suite["regression"]["cases"]
        cls.appendix = Section("appendix-c", 1, "C", Text("評価", "Evaluation"), appendix="C")
        evaluation.append_rubric_sections(cls.appendix, ROOT)

    def rows(self, name):
        return list(csv.DictReader(io.StringIO((self.root / name).read_text(encoding="utf-8-sig"))))

    def test_distributed_suite_and_assets_reproduce_the_unchanged_public_sources(self):
        self.assertEqual(native_evaluation.original_suite(ROOT), self.suite["original"])
        regression = json.loads((ROOT / "tools/data-agent/regression/extended-suite.json").read_text(encoding="utf-8"))
        self.assertEqual(regression, self.suite["regression"])
        for filename, expected in evaluation.build_assets(ROOT).items():
            with self.subTest(asset=filename):
                self.assertEqual(expected, (self.root / filename).read_bytes())
        self.assertTrue(self.suite["publicNotUnseen"])
        self.assertFalse(self.suite["protocol"]["historicalPrivateQuestionsIncluded"])

    def test_current_evaluation_guidance_does_not_narrate_retired_campaigns(self):
        model = chapter(19)
        evaluation.append_chapter_sections(model, ROOT)
        rendered = str(model) + str(participant_text.CHAPTERS[19])
        for retired in ("51-slot", "51 slots", "51スロット", "296 conditions", "296条件"):
            self.assertNotIn(retired, rendered)
        self.assertIn("49", rendered)
        self.assertIn("290", rendered)
        self.assertIn("10,000 UTF-16", rendered)
        self.assertIn("Measure the selected profile's actual length", rendered)
        self.assertNotIn("already fills", rendered)

    def test_fixed_distribution_path_note_precedes_first_setup_path(self):
        model = chapter(19)
        evaluation.append_chapter_sections(model, ROOT)
        first = model.children[0]
        note = first.blocks[0]["text"]
        for language in ("ja", "en"):
            value = getattr(note, language)
            for name in ("v3.0.0-preview", "v2.7.0",
                         "requirements-preview30.txt", "build_preview30.py"):
                self.assertIn(name, value)
        self.assertIn("表示どおり", note.ja)
        self.assertIn("exactly as shown", note.en)
        self.assertIn("participant-evaluation", first.blocks[1]["text"].en)

    def test_participant_target_guidance_does_not_embed_the_shared_deployment(self):
        rendered = str(participant_text.CHAPTERS[17])
        for identifier in (
            "003b6460-da51-4426-be11-3e4e2f2ef207",
            "928dd874-020c-4ba7-a380-3cffd0598381",
            "143717",
            "DA_Furusato_101",
            "comparison is in progress",
        ):
            self.assertNotIn(identifier, rendered)

    def test_questions_and_all_122_unique_rubric_conditions_are_complete_in_both_languages(self):
        self.assertEqual(29, len(self.cases))
        self.assertEqual(29, len(self.appendix.children))
        questions = self.rows("questions.csv")
        rubric = self.rows("rubric.csv")
        self.assertEqual(29, len(questions))
        self.assertEqual(122, len(rubric))
        self.assertEqual(122, len({row["condition_id"] for row in rubric}))
        self.assertEqual([c["question"] for c in self.cases], [r["question_ja"] for r in questions])
        self.assertEqual([(c["id"], condition["id"], condition["text"])
                          for c in self.cases for condition in c["conditions"]],
                         [(r["case_id"], r["condition_id"], r["criterion_ja"]) for r in rubric])
        for case, section in zip(self.cases, self.appendix.children):
            with self.subTest(case=case["id"]):
                self.assertEqual([case["question"]], [b["text"] for b in code_blocks(section)])
                self.assertTrue(code_blocks(section)[0].get("canonicalLiteral"))
                tables = [b for b in section.blocks if b.kind == "table"]
                for language in ("ja", "en"):
                    cells = [cell.get(language) for table in tables for row in table["rows"] for cell in row]
                    self.assertIn(case["expected"], cells)
                    self.assertIn(evaluation.DISPLAY_TRANSLATIONS["expected"][case["id"]], cells)
                    if "query_shape" in case:
                        self.assertIn(case["query_shape"], cells)
                    for condition in case["conditions"]:
                        self.assertIn(condition["id"], cells)
                        self.assertIn(condition["text"], cells)
                        self.assertIn(
                            evaluation.DISPLAY_TRANSLATIONS["conditions"][condition["id"]],
                            cells,
                        )
                    if "expected_values" in case:
                        def leaves(value):
                            if isinstance(value, dict):
                                return [leaf for child in value.values() for leaf in leaves(child)]
                            if isinstance(value, list):
                                return [leaf for child in value for leaf in leaves(child)]
                            return ["null" if value is None else str(value)]
                        self.assertCountEqual(leaves(case["expected_values"]),
                                              [row[1].get(language) for row in tables[-1]["rows"]])

    def test_appendix_c_display_translations_are_additive_and_complete(self):
        expected_cases = {case["id"] for case in self.cases}
        condition_ids = {condition["id"] for case in self.cases for condition in case["conditions"]}
        self.assertEqual(expected_cases, set(evaluation.DISPLAY_TRANSLATIONS["expected"]))
        self.assertEqual(condition_ids, set(evaluation.DISPLAY_TRANSLATIONS["conditions"]))
        for case, section in zip(self.cases, self.appendix.children):
            expected_table, criteria_table = [
                block for block in section.blocks if block.kind == "table"
            ][:2]
            self.assertEqual(
                ["Condition ID", "Scoring criterion (verbatim Japanese)", "English explanation"],
                [header.en for header in criteria_table["headers"]],
            )
            expected_cells = [cell for row in expected_table["rows"] for cell in row]
            self.assertIn(case["expected"], [cell.en for cell in expected_cells])
            self.assertIn(
                evaluation.DISPLAY_TRANSLATIONS["expected"][case["id"]],
                [cell.en for cell in expected_cells],
            )
            for condition in case["conditions"]:
                row = next(row for row in criteria_table["rows"] if row[0].en == condition["id"])
                self.assertEqual(condition["text"], row[1].en)
                self.assertEqual(
                    evaluation.DISPLAY_TRANSLATIONS["conditions"][condition["id"]],
                    row[2].en,
                )

    def test_blank_templates_register_every_49_slot_and_290_condition_per_phase(self):
        slots, conditions = self.rows("slots-template.csv"), self.rows("conditions-template.csv")
        paired = self.rows("paired-template.csv")
        self.assertEqual(98, len(slots))
        self.assertEqual(580, len(conditions))
        self.assertEqual(290, len(paired))
        case_map = {c["id"]: c for c in self.cases}
        expected_keys = {(kind, str(repeat), case["id"], condition["id"])
                         for kind, repeats in (("original", 3), ("regression", 1))
                         for repeat in range(1, repeats + 1)
                         for case in self.suite[kind]["cases"] for condition in case["conditions"]}
        keys = lambda rows: {(r["suite"], r["repeat"], r["case_id"], r["condition_id"]) for r in rows}
        self.assertEqual(expected_keys, keys(paired))
        for phase in ("baseline", "final"):
            phase_slots = [r for r in slots if r["phase"] == phase]
            phase_conditions = [r for r in conditions if r["phase"] == phase]
            self.assertEqual(49, len(phase_slots))
            self.assertEqual(49, len({r["slot_id"] for r in phase_slots}))
            self.assertEqual(290, len(phase_conditions))
            self.assertEqual(expected_keys, keys(phase_conditions))
            for row in phase_slots:
                self.assertEqual(case_map[row["case_id"]]["question"], row["question_ja"])
                self.assertEqual("", row["native_status"])
                self.assertEqual("", row["response_status"])
            for row in phase_conditions:
                self.assertEqual("", row["status"])
                self.assertEqual("", row["private_evidence_file_and_location"])

    def test_evaluation_answers_stay_separate_from_the_four_configuration_fields(self):
        model = chapter(17)
        tuning.append_tuning_sections(model, ROOT, figures=FigureFactory(None, {}))
        instructions = [b["text"] for b in code_blocks(model) if b["language"].en == "instructions"]
        self.assertEqual(4, len(instructions))
        for case in self.cases:
            for body in instructions:
                self.assertNotIn(case["question"], body)
                self.assertNotIn(case["expected"], body)
        for body in instructions:
            self.assertEqual([], _answer_values_in(body))


if __name__ == "__main__":
    unittest.main()
