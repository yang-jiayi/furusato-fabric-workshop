# 12. Semantic model と Ontology の Metrics

[Lab 目次](../README.md)

12. Semantic model and ontology Metrics

- [12.1 この章で行うこと](01-12-1-what-you-will-do.md)
- [12.2 操作手順（1）](02-12-2-pc-12-semantic-model-view.md)
- [12.2 操作手順（2）](03-12-2-p30-12-metric-list.md)
- [12.2 操作手順（3）](04-12-2-p30-12-metrics.md)
- [12.2 操作手順（4）](05-12-2-pc-12-report-canvas.md)
- [12.3 完了の確認](06-12-3-check-your-work.md)
- [12.4 参照表](07-12-4-reference-tables.md)
- [12.5 参考資料](08-12-5-references.md)
- [12.6 モデルを Prep for AI で準備する](09-12-6-prepare-the-model-for-ai.md)
- [12.7 AI 設定の確認と任意の Verified answers](10-12-7-verify-ai-preparation-and-optional-verified-answers.md)
