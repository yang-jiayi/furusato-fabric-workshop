"""Integrity boundaries for the explicit standalone current delivery route."""
from hashlib import sha256
from contextlib import redirect_stderr
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

ROOT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(ROOT/'tools/docs'),str(ROOT/'tools/html')]
import current_delivery as delivery
from furusato_html.preview30 import render
from furusato_docs import preview30_release as release
from furusato_docs.current_publication import CurrentPublication, publication_for_model
from furusato_docs.participant30_deployment import append_deployment_sections
from furusato_docs.participant30_text import PARAMETER_NOTES
from furusato_html.model import Section, Text


class CurrentDeliveryTests(unittest.TestCase):
    def test_retired_word_guard_distinguishes_literal_source_vocabulary(self):
        self.assertFalse(delivery.retired_guide_reference(
            'It usually opens with a place-of-origin word such as a prefecture name.'))
        for value in ('Use Word or HTML', 'Read guide.DOCX', 'Open microsoft word',
                      'use the word document', 'download the word file'):
            with self.subTest(value=value):
                self.assertTrue(delivery.retired_guide_reference(value))

    def test_exact_experimental_profile_inputs_are_bound_in_current_package(self):
        files=delivery.current_profile_files(ROOT)
        self.assertEqual(len(files),9)
        self.assertTrue(all(name.startswith(delivery.CURRENT_PROFILE_DIR+'/') for name in files))
        self.assertIn(delivery.CURRENT_PROFILE_DIR+'/global-instructions.txt',files)
        with tempfile.TemporaryDirectory() as temp:
            import shutil
            root=Path(temp)
            shutil.copytree(ROOT/delivery.CURRENT_PROFILE_DIR,root/delivery.CURRENT_PROFILE_DIR)
            (root/delivery.CURRENT_PROFILE_DIR/'global-instructions.txt').write_text('drift',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'profile hash mismatch'):
                delivery.current_profile_files(root)

    def test_participant_checksums_and_notebook_help_follow_current_edition(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            scope = root / 'workshop/v3.0.0-preview/provisioning/scope.example.json'
            scope.parent.mkdir(parents=True)
            scope.write_bytes((ROOT / scope.relative_to(root)).read_bytes())
            for version in ('3.0.0', '3.1.0'):
                (root / 'WORKSHOP_VERSION').write_text(version, encoding='utf-8')
                section = Section('ch-24', 1, '24', Text('Deployment', 'Deployment'), chapter=24)
                append_deployment_sections(section, root)
                text = repr(section)
                self.assertIn(f'docs/v{version}/current', text)
                self.assertIn(CurrentPublication(version).package_name, text)
                self.assertNotIn('current-20261015.zip', text)
                self.assertIn('source/workshop/v3.0.0-preview', text)
        for description in PARAMETER_NOTES['NOTEBOOK_VERSION']:
            self.assertIn('NOTEBOOK_VERSION', description)
            self.assertNotIn('3.0.0', description)

    def test_current_filenames_follow_workshop_version_without_rewriting_word_profiles(self):
        version=(ROOT/'WORKSHOP_VERSION').read_text(encoding='utf-8').strip()
        self.assertEqual(delivery.PUBLICATION.version,version)
        self.assertEqual(delivery.HTML_NAME,'furusato-workshop-v'+version.replace('.','-')+'-complete.html')
        self.assertEqual(delivery.PACKAGE_NAME,'Furusato_Workshop_v'+version+'_current.zip')
        self.assertEqual(release.V300.version,'3.0.0')
        self.assertEqual(release.V300.html_name,'furusato-workshop-v3-0-0-complete.html')
        for invalid in ('3.1','../3.1.0','3.1.0/guide','3.1.0-preview'):
            with self.subTest(version=invalid),self.assertRaises(ValueError):
                CurrentPublication(invalid)

    def test_standalone_version_binding_is_independent_of_historical_word_approval(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            for version in ('3.0.0','3.1.0'):
                (root/'WORKSHOP_VERSION').write_text(version,encoding='utf-8')
                metadata={'version':version,'participantEdition':True,'deliveryMode':'html-lab',
                          'currentArtifactSet':{'workshopVersion':version}}
                self.assertEqual(publication_for_model(root,metadata,None,None).version,version)
                for word_sha,profile in ((None,release.V300),('b'*64,None)):
                    with self.subTest(version=version,profile=profile),self.assertRaises(ValueError):
                        publication_for_model(root,metadata,word_sha,profile)
                metadata['currentArtifactSet']['workshopVersion']='2.7.0'
                with self.assertRaises(ValueError):
                    publication_for_model(root,metadata,None,None)

    def test_explicit_browser_takes_priority_on_linux_and_windows(self):
        chromium=object()
        for platform in ('linux','win32'):
            with self.subTest(platform=platform),patch.object(delivery.sys,'platform',platform),patch.object(Path,'is_file',return_value=True):
                self.assertEqual(delivery.select_browser_executable(chromium,Path('custom-browser')),Path('custom-browser').resolve())

    def test_missing_explicit_browser_does_not_fall_back(self):
        with patch.object(Path,'is_file',return_value=False),self.assertRaisesRegex(FileNotFoundError,'existing file'):
            delivery.select_browser_executable(object(),Path('missing-browser'))

    def test_linux_prefers_existing_system_chromium(self):
        with patch.object(delivery.sys,'platform','linux'),patch.object(Path,'is_file',return_value=True):
            self.assertEqual(delivery.select_browser_executable(object()),Path('/usr/bin/chromium'))

    def test_playwright_chromium_fallback_on_windows_and_linux(self):
        installed=Path('playwright-chromium')
        chromium=Mock(executable_path=str(installed))
        for platform in ('linux','win32'):
            with self.subTest(platform=platform),patch.object(delivery.sys,'platform',platform),patch.object(Path,'is_file',autospec=True,side_effect=lambda path:path==installed):
                self.assertEqual(delivery.select_browser_executable(chromium),installed)

    def test_missing_playwright_browser_reports_dependency(self):
        with patch.object(delivery.sys,'platform','win32'),patch.object(Path,'is_file',return_value=False):
            with self.assertRaisesRegex(FileNotFoundError,'python -m playwright install chromium'):
                delivery.select_browser_executable(Mock(executable_path='missing-playwright-browser'))

    def test_browser_executable_argument_requires_browser_and_existing_file(self):
        cases=[
            ['validate','--out','.','--browser-executable',__file__],
            ['validate','--out','.','--browser','--browser-executable','.'],
            ['validate','--out','.','--browser','--browser-executable','missing-browser'],
            ['build','--out','.','--browser-executable',__file__],
            ['package','--out','.','--package','package.zip','--browser-executable',__file__],
        ]
        for argv in cases:
            with self.subTest(argv=argv),redirect_stderr(io.StringIO()),self.assertRaises(SystemExit) as error:
                delivery.parse_args(argv)
            self.assertEqual(error.exception.code,2)

    def test_browser_arguments_accept_explicit_and_default_selection(self):
        args=delivery.parse_args(['validate','--out','.','--browser','--browser-executable',__file__])
        self.assertTrue(args.browser)
        self.assertEqual(args.browser_executable,Path(__file__))
        args=delivery.parse_args(['validate','--out','.','--browser'])
        self.assertTrue(args.browser)
        self.assertIsNone(args.browser_executable)
        self.assertFalse(delivery.parse_args(['validate','--out','.']).browser)

    def test_paired_renderer_still_requires_original_release_binding(self):
        with self.assertRaises(ValueError):
            render(None,None,None,None,None,{'version':'3.0.0'},'a'*64,ROOT,release_profile=release.V300)

    def test_standalone_renderer_rejects_paired_digest_or_unbound_model(self):
        for metadata, word_sha in [
            ({'version':'3.0.0','participantEdition':True,'deliveryMode':'html-lab'},None),
            ({'version':'3.0.0','participantEdition':True,'deliveryMode':'html-lab','currentArtifactSet':{'sourceCommit':'a'*40}},'b'*64),
        ]:
            with self.subTest(metadata=metadata,word_sha=word_sha),self.assertRaises(ValueError):
                render(None,None,None,None,None,metadata,word_sha,ROOT,release_profile=release.V300,delivery_mode='html-lab')

    def test_packaging_requires_completed_browser_checks_on_exact_bytes(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/delivery.HTML_NAME
            path.write_text('first html')
            sha=sha256(path.read_bytes()).hexdigest()
            receipt={'schemaVersion':'furusato-current-html-lab-validation/v1','deliveryMode':'html-lab',
                     'static':{'passed':True,'htmlSha256':sha},'browser':{'passed':False,'htmlSha256':sha}}
            with self.assertRaises(ValueError):delivery.require_validated(path,receipt)
            receipt['browser']['passed']=True
            delivery.require_validated(path,receipt)
            path.write_text('modified html')
            with self.assertRaises(ValueError):delivery.require_validated(path,receipt)

    def test_unexpected_private_lab_files_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            (root/'README.md').write_text('Expected guide')
            delivery.checked_lab_files(root,{'README.md'})
            for name in ('.env','storage-state.json','extra.md'):
                path=root/name
                path.write_text('private test fixture')
                with self.subTest(name=name),self.assertRaises(ValueError):
                    delivery.checked_lab_files(root,{'README.md'})
                path.unlink()

    def test_unapproved_private_authoring_files_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            directory=root/'tools/docs';directory.mkdir(parents=True)
            (directory/'current_delivery.py').write_text('# known authoring source')
            self.assertEqual(delivery.approved_doc_files(root,set()),{'tools/docs/current_delivery.py'})
            for name in ('.env','storage-state.json','unreviewed-helper.py'):
                path=directory/name
                path.write_text('private test fixture')
                with self.subTest(name=name),self.assertRaises(ValueError):
                    delivery.approved_doc_files(root,set())
                path.unlink()

    def test_expected_lab_filename_cannot_hide_appended_private_content(self):
        with tempfile.TemporaryDirectory() as temp:
            lab=Path(temp);path=lab/'README.md';expected=b'Generated current index\n'
            path.write_bytes(expected)
            delivery.checked_lab_files(lab,{'README.md':expected})
            path.write_bytes(expected+b'PRIVATE TEST FIXTURE\n')
            with self.assertRaises(ValueError):delivery.checked_lab_files(lab,{'README.md':expected})

    def test_supplied_manifest_cannot_bypass_private_path_guard(self):
        for name in ('tools/docs/.env','tools/data-agent/private/answer.json','tools/docs/storage-state.json'):
            with self.subTest(name=name),self.assertRaises(ValueError):
                delivery.validate_source_manifest_paths(ROOT,{'files':{name:'0'*64}})

    def test_external_staged_lab_links_use_the_virtual_repository_layout(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)/'repo';root.mkdir();(root/'workshop/v3.0.0-preview').mkdir(parents=True)
            lab=Path(temp)/'stage/Lab';lab.mkdir(parents=True)
            (lab/'README.md').write_text('[HTML](../docs/'+delivery.HTML_NAME+')\n[Source](../workshop/v3.0.0-preview)')
            source='workshop/v3.0.0-preview/notebook.txt'
            files={'source/'+source:b'test public source'}
            delivery.add_lab_aliases(files,root,lab,{source:'0'*64},b'validated html')
            self.assertEqual(files['docs/'+delivery.HTML_NAME],b'validated html')
            self.assertEqual(files[source],b'test public source')

    def test_bilingual_markdown_links_are_read_as_utf8(self):
        with tempfile.TemporaryDirectory() as temp:
            lab=Path(temp)
            page=lab/'README.md'
            page.write_text('[準備](../docs/guide.html)\n',encoding='utf-8')
            original=Path.read_text
            def explicit_utf8(path,*args,**kwargs):
                self.assertEqual(kwargs.get('encoding'),'utf-8')
                return original(path,*args,**kwargs)
            with patch.object(Path,'read_text',explicit_utf8):
                self.assertEqual(list(delivery.markdown_links(lab)),[(page,'../docs/guide.html')])

    def test_extracted_lab_links_must_resolve_inside_actual_package(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            lab=root/'Lab';lab.mkdir()
            (lab/'README.md').write_text('[Guide](../docs/guide.html)')
            with self.assertRaises(ValueError):delivery.validate_packaged_links(root)
            (root/'docs').mkdir();(root/'docs/guide.html').write_text('actual html')
            self.assertEqual(delivery.validate_packaged_links(root),1)


if __name__=='__main__':unittest.main()
